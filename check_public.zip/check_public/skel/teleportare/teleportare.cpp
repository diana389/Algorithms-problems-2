#include <iostream>
#include <cstdint>
#include <fstream>
#include <vector>

using namespace std;

int main()
{
    freopen("teleportare.in", "r", stdin);
    freopen("teleportare.out", "w", stdout);

    int N, M, K, X, Y, T, P;

    cin >> N >> M >> K;

    for (int i = 0; i < M; i++)
    {
        cin >> X >> Y >> T;
    }

    for (int i = 0; i < K; i++)
    {
        cin >> X >> Y >> P;
    }

    cout << 0;

    return 0;
}
