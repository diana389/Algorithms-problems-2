#include <iostream>
#include <vector>
using namespace std;

int main() {
    freopen("supercomputer.in", "r", stdin);
    freopen("supercomputer.out", "w", stdout);

    int N, M, a, x, y;

    cin >> N >> M;
    for(int i = 0; i < N; i++)
        cin >> a;

    for(int i = 0; i < M; i++) {
        cin >> x >> y;
    }

    cout << 0;

    return 0;
}
