#include <iostream>

using namespace std;

int main()
{
	freopen("magazin.in", "r", stdin);
	freopen("magazin.out", "w", stdout);

	int N, Q, x, D, E;

	cin >> N >> Q;

	for (int i = 0; i < N - 1; i++)
	{
		cin >> x;
	}

	for (int i = 0; i < Q; i++)
	{
		cin >> D >> E;
		cout << 0 << '\n';
	}

	return 0;
}