#include <iostream>
#include <cstdint>
#include <fstream>
#include <vector>

using namespace std;

int main()
{
    freopen("ferate.in", "r", stdin);
    freopen("ferate.out", "w", stdout);

    int N, M, S, x, y;

    cin >> N >> M >> S;

    for (int i = 0; i < M; i++)
    {
        cin >> x >> y;
    }

    cout << 0;

    return 0;
}
